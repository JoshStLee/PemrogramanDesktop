﻿Imports AxWMPLib
Imports Id3
Imports Id3.Frames
Imports System.IO
Imports System.Threading
Imports System.Timers

Public Class frmEditor
    Private filepath As String = ""
    Private version As Byte
    Public Sub GetFile(filename As String)
        filepath = filename
        Dim title As String = Path.GetFileNameWithoutExtension(filename)
        Dim file = New Mp3(filepath, Mp3Permissions.Read)
        If file.HasTags Then
            Dim trackTag = New Id3Tag()
            If file.HasTagOfVersion(Id3Version.V23) Then
                trackTag = file.GetTag(Id3TagFamily.Version2X)
            ElseIf file.HasTagOfVersion(Id3Version.V1X) Then
                trackTag = file.GetTag(Id3TagFamily.Version1X)
            Else
                trackTag = file.GetTag(Id3TagFamily.Version2X)
            End If
            txtTitle.Text = trackTag.Title
            txtArtist.Text = trackTag.Artists.Value(0)
            txtAlbum.Text = trackTag.Album
            txtYear.Text = trackTag.Year
            txtTrackNum.Text = trackTag.Track
            'If trackTag.Lyrics.Count > 0 Then
            'RTBoxLyrics.Text = trackTag.Lyrics.FirstOrDefault.Lyrics
            'End If
            If System.IO.File.Exists(filepath + ".txt") Then
                Using reader As New StreamReader(filepath + ".txt")
                    Dim line, lines As String
                    lines = ""
                    Do
                        line = reader.ReadLine
                        If line Is Nothing Then Exit Do
                        RTBoxLyrics.Text += line + vbCrLf
                    Loop
                End Using
            End If
        End If
        file.Dispose()
    End Sub

    Private Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        Dim file = New Mp3(filepath, Mp3Permissions.ReadWrite)
        Try
            Dim trackTag = New Id3Tag()
            Dim lyricFrame = New LyricsFrame
            If file.HasTagOfVersion(Id3Version.V1X) Then
                trackTag = file.GetTag(Id3TagFamily.Version1X)
            ElseIf file.HasTagOfVersion(Id3Version.V23) Then
                trackTag = file.GetTag(Id3TagFamily.Version2X)
            Else
                trackTag = file.GetTag(Id3TagFamily.Version2X)
            End If
            MsgBox(version)
            If trackTag Is Nothing Then
                MsgBox("Tag is null")
                trackTag = New Id3Tag()

                'tag.Version = Id3Version.V23;
                'version Is internal set, but if we use reflection to set it,
                'the mp3.WriteTag below works.
                Dim propinfo = GetType(Id3Tag).GetProperty("Version", System.Reflection.BindingFlags.Public Or System.Reflection.BindingFlags.Instance)
                propinfo.SetValue(trackTag, Id3Version.V23)
                version = Id3TagFamily.Version2X
            End If
            lyricFrame.Lyrics = RTBoxLyrics.Text
            trackTag.Track.Value = Val(txtTrackNum.Text)

            trackTag.Title.Value = txtTitle.Text

            trackTag.Artists.Value.Clear()
            trackTag.Artists.Value.Add(txtArtist.Text)

            trackTag.Album.Value = txtAlbum.Text

            trackTag.Year.Value = Val(txtYear.Text)

            'error not implemented from Jeevan's repo
            'trackTag.Lyrics.Add(lyricFrame)
            'trackTag.Lyrics.Clear()
            Dim writer As System.IO.StreamWriter
            writer = My.Computer.FileSystem.OpenTextFileWriter(filepath + ".txt", False)
            writer.WriteLine(RTBoxLyrics.Text)
            writer.Close()
            file.WriteTag(trackTag, Id3Version.V23, WriteConflictAction.Replace)
            file.Dispose()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            txtTrackNum.ReadOnly = True
            txtTitle.ReadOnly = True
            txtArtist.ReadOnly = True
            txtAlbum.ReadOnly = True
            txtYear.ReadOnly = True
            file.Dispose()
            Me.Dispose()
            Me.Close()
        End Try
    End Sub

    Private Sub CutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CutToolStripMenuItem.Click
        RTBoxLyrics.Cut()
    End Sub

    Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem.Click
        RTBoxLyrics.Copy()
    End Sub

    Private Sub PasteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PasteToolStripMenuItem.Click
        RTBoxLyrics.Paste()
    End Sub
End Class