﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPlaylist
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblDir = New System.Windows.Forms.Label()
        Me.txtDir = New System.Windows.Forms.TextBox()
        Me.BtnBrowse = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.lvMp3 = New System.Windows.Forms.ListView()
        Me.chTrackNum = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chTitle = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chArtist = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chAlbum = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chYear = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chLength = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chFileSize = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chLastModified = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chCreatedDate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.SelectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelectNoneToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditTrackToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddToPlaylistToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteFromPlaylistToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveAsPlaylistToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowTagToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.RefreshToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblDir
        '
        Me.lblDir.AutoSize = True
        Me.lblDir.Location = New System.Drawing.Point(13, 13)
        Me.lblDir.Name = "lblDir"
        Me.lblDir.Size = New System.Drawing.Size(49, 13)
        Me.lblDir.TabIndex = 0
        Me.lblDir.Text = "Directory"
        '
        'txtDir
        '
        Me.txtDir.Location = New System.Drawing.Point(78, 9)
        Me.txtDir.Name = "txtDir"
        Me.txtDir.Size = New System.Drawing.Size(612, 20)
        Me.txtDir.TabIndex = 1
        Me.txtDir.Text = "click to select a folder "
        '
        'BtnBrowse
        '
        Me.BtnBrowse.Location = New System.Drawing.Point(696, 7)
        Me.BtnBrowse.Name = "BtnBrowse"
        Me.BtnBrowse.Size = New System.Drawing.Size(92, 23)
        Me.BtnBrowse.TabIndex = 2
        Me.BtnBrowse.Text = "Select Playlist"
        Me.BtnBrowse.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'lvMp3
        '
        Me.lvMp3.AllowColumnReorder = True
        Me.lvMp3.CheckBoxes = True
        Me.lvMp3.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chTrackNum, Me.chTitle, Me.chArtist, Me.chAlbum, Me.chYear, Me.chLength, Me.chFileSize, Me.chLastModified, Me.chCreatedDate})
        Me.lvMp3.ContextMenuStrip = Me.ContextMenuStrip1
        Me.lvMp3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.lvMp3.FullRowSelect = True
        Me.lvMp3.GridLines = True
        Me.lvMp3.HideSelection = False
        Me.lvMp3.Location = New System.Drawing.Point(0, 36)
        Me.lvMp3.Name = "lvMp3"
        Me.lvMp3.Size = New System.Drawing.Size(800, 414)
        Me.lvMp3.TabIndex = 3
        Me.lvMp3.UseCompatibleStateImageBehavior = False
        Me.lvMp3.View = System.Windows.Forms.View.Details
        '
        'chTrackNum
        '
        Me.chTrackNum.Text = "#"
        '
        'chTitle
        '
        Me.chTitle.Text = "Title"
        '
        'chArtist
        '
        Me.chArtist.Text = "Artist"
        '
        'chAlbum
        '
        Me.chAlbum.Text = "Album"
        '
        'chYear
        '
        Me.chYear.Text = "Year"
        '
        'chLength
        '
        Me.chLength.Text = "Length"
        '
        'chFileSize
        '
        Me.chFileSize.Text = "File Size"
        '
        'chLastModified
        '
        Me.chLastModified.Text = "Last Modified"
        '
        'chCreatedDate
        '
        Me.chCreatedDate.Text = "Created Date"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SelectAllToolStripMenuItem, Me.SelectNoneToolStripMenuItem, Me.EditTrackToolStripMenuItem, Me.AddToPlaylistToolStripMenuItem, Me.DeleteFromPlaylistToolStripMenuItem, Me.SaveAsPlaylistToolStripMenuItem, Me.ShowTagToolStripMenuItem, Me.RefreshToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(181, 202)
        '
        'SelectAllToolStripMenuItem
        '
        Me.SelectAllToolStripMenuItem.Name = "SelectAllToolStripMenuItem"
        Me.SelectAllToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.SelectAllToolStripMenuItem.Text = "Select All "
        '
        'SelectNoneToolStripMenuItem
        '
        Me.SelectNoneToolStripMenuItem.Name = "SelectNoneToolStripMenuItem"
        Me.SelectNoneToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.SelectNoneToolStripMenuItem.Text = "Select None"
        '
        'EditTrackToolStripMenuItem
        '
        Me.EditTrackToolStripMenuItem.Name = "EditTrackToolStripMenuItem"
        Me.EditTrackToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.EditTrackToolStripMenuItem.Text = "Edit Track"
        '
        'AddToPlaylistToolStripMenuItem
        '
        Me.AddToPlaylistToolStripMenuItem.Name = "AddToPlaylistToolStripMenuItem"
        Me.AddToPlaylistToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.AddToPlaylistToolStripMenuItem.Text = "Add To Playlist"
        '
        'DeleteFromPlaylistToolStripMenuItem
        '
        Me.DeleteFromPlaylistToolStripMenuItem.Name = "DeleteFromPlaylistToolStripMenuItem"
        Me.DeleteFromPlaylistToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.DeleteFromPlaylistToolStripMenuItem.Text = "Delete From Playlist"
        '
        'SaveAsPlaylistToolStripMenuItem
        '
        Me.SaveAsPlaylistToolStripMenuItem.Name = "SaveAsPlaylistToolStripMenuItem"
        Me.SaveAsPlaylistToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.SaveAsPlaylistToolStripMenuItem.Text = "Save To Playlist"
        '
        'ShowTagToolStripMenuItem
        '
        Me.ShowTagToolStripMenuItem.Name = "ShowTagToolStripMenuItem"
        Me.ShowTagToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ShowTagToolStripMenuItem.Text = "Show Tag"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'RefreshToolStripMenuItem
        '
        Me.RefreshToolStripMenuItem.Name = "RefreshToolStripMenuItem"
        Me.RefreshToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.RefreshToolStripMenuItem.Text = "Refresh"
        '
        'frmPlaylist
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lvMp3)
        Me.Controls.Add(Me.BtnBrowse)
        Me.Controls.Add(Me.txtDir)
        Me.Controls.Add(Me.lblDir)
        Me.Name = "frmPlaylist"
        Me.Text = "Playlist"
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDir As Label
    Friend WithEvents txtDir As TextBox
    Friend WithEvents BtnBrowse As Button
    Friend WithEvents ImageList1 As ImageList
    Friend WithEvents chTrackNum As ColumnHeader
    Friend WithEvents chTitle As ColumnHeader
    Friend WithEvents chArtist As ColumnHeader
    Friend WithEvents chAlbum As ColumnHeader
    Friend WithEvents chYear As ColumnHeader
    Friend WithEvents chFileSize As ColumnHeader
    Friend WithEvents chLastModified As ColumnHeader
    Friend WithEvents chCreatedDate As ColumnHeader
    Friend WithEvents chLength As ColumnHeader
    Friend WithEvents FolderBrowserDialog1 As FolderBrowserDialog
    Friend WithEvents lvMp3 As ListView
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents EditTrackToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveAsPlaylistToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DeleteFromPlaylistToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents AddToPlaylistToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SelectAllToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SelectNoneToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ShowTagToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RefreshToolStripMenuItem As ToolStripMenuItem
End Class
