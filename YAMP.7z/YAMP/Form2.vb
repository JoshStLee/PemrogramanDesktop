﻿Imports System.IO
Imports System.Net.WebRequestMethods
Imports System.Security.Claims
Imports System.Security.Cryptography
Imports System.Web.UI.WebControls
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports AxWMPLib
Imports Fizzler
Imports Id3
Imports Microsoft.Win32
Imports Svg

Public Class frmPlaylist
    Public editor As New frmEditor
    Public player As New frmPlayer
    Dim index As New Integer
    Dim sortColumn As Integer = -1
    Private Function FormatFileSize(ByVal FileSizeBytes As Long) As String
        Dim sizeTypes() As String = {"b", "Kb", "Mb", "Gb"}
        Dim Len As Decimal = FileSizeBytes
        Dim sizeType As Integer = 0
        Do While Len > 1024
            Len = Decimal.Round(Len / 1024, 2)
            sizeType += 1
            If sizeType >= sizeTypes.Length - 1 Then Exit Do
        Loop

        Dim Resp As String = Len.ToString & " " & sizeTypes(sizeType)
        Return Resp
    End Function

    Private Sub PlayFile(filename As String)
        If player Is Nothing OrElse player.IsDisposed Then
            player = New frmPlayer
        End If
        player.filepath = filename
        player.Timer1.Enabled = True
        player.Timer2.Enabled = True
        player.BtnPlayPause.Image = My.Resources.pause
        player.Hide()
        player.Show()
        player.GetFile()
    End Sub

    Private Sub AddtoList(ByVal nFile As String)
        Dim LItem As ListViewItem
        Dim sExtension As String = Path.GetExtension(nFile)
        sExtension = sExtension.ToLower
        If (Trim(sExtension) = ".mp3" = True) Or (Trim(sExtension) = ".wav" = True) Then
            Dim f As FileInfo = New FileInfo(nFile)
            Dim file As Mp3 = New Mp3(nFile, Mp3Permissions.Read)
            Dim tag As Id3Tag = New Id3Tag()
            Dim att As String = f.Attributes.ToString
            Dim size As String = f.Length.ToString
            Dim dibuat As String = f.CreationTime.ToString
            Dim akses As String = f.LastAccessTime.ToString
            Dim modi As String = f.LastWriteTime.ToString
            Dim trackNum As String = ""
            Dim title As String = ""
            Dim artists As String = ""
            Dim album As String = ""
            Dim year As String = ""
            Dim length As String = ""
            LItem = New ListViewItem()
            title = Path.GetFileNameWithoutExtension(nFile)
            If file.HasTags Then
                If file.HasTagOfVersion(Id3Version.V1X) Then
                    tag = file.GetTag(Id3TagFamily.Version1X)
                ElseIf File.HasTagOfVersion(Id3Version.V23) Then
                    tag = File.GetTag(Id3TagFamily.Version2X)
                Else
                    tag = File.GetTag(Id3TagFamily.Version2X)
                End If
                trackNum = tag.Track
                title = tag.Title
                If tag.Artists.Value.Count > 0 Then
                    artists = tag.Artists.Value(0)
                End If
                album = tag.Album
                year = tag.Year
                length = tag.Length.ToString
            End If

            With LItem
                .SubItems(0).Text = trackNum
                .SubItems.Add(title)
                .SubItems.Add(artists)
                .SubItems.Add(album)
                .SubItems.Add(year)
                .SubItems.Add(length)
                .SubItems.Add(FormatFileSize(size))
                .SubItems.Add(modi)
                .SubItems.Add(akses)
                .SubItems.Add(dibuat)
                .ImageKey = sExtension
                .Tag = nFile
            End With
            lvMp3.Items.Add(LItem)
            file.Dispose()
        End If
    End Sub

    Private Sub GetSongsFromPlaylist(ByVal text As String)
        Dim nFile As String
        lvMp3.Items.Clear()
        lvMp3.BeginUpdate()
        Using reader As New StreamReader(text)
            Do
                nFile = reader.ReadLine
                If (nFile) Is Nothing Then Exit Do
                AddtoList(nFile)
            Loop
        End Using
        txtDir.Text = text
        SetAsDefault()
        lvMp3.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize)
        lvMp3.EndUpdate()
        For i = 0 To lvMp3.Items.Count - 1
            lvMp3.Items(i).Checked = True
        Next
    End Sub

    Private Sub GetFiles(ByVal PathName As String)
        lvMp3.Items.Clear()
        lvMp3.BeginUpdate()

        For Each nFile As String In Directory.GetFiles(PathName)
            AddtoList(nFile)
        Next
        lvMp3.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize)
        lvMp3.EndUpdate()
        txtDir.Text = PathName
        SetAsDefault()
    End Sub

    Private Sub FindFile(filename As String)
        For Each item In lvMp3.Items
            If item.tag = filename Then
                index = lvMp3.Items.IndexOf(item)
                Exit For
            End If
        Next

    End Sub

    Private Sub BtnBrowse_Click(sender As Object, e As EventArgs) Handles BtnBrowse.Click
        Dim dr As DialogResult
        dr = OpenFileDialog1.ShowDialog()
        If dr = DialogResult.OK Then
            GetSongsFromPlaylist(OpenFileDialog1.FileName)
        End If
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim s() As String = System.Environment.GetCommandLineArgs()
        If Not s.Length = 1 Then
            GetFiles(Path.GetDirectoryName(s(1)))
            FindFile(s(1))
            txtDir.Text = ""
            Me.WindowState = FormWindowState.Minimized
            frmPlayer.BringToFront()
            PlayFile(s(1))
        End If
        If System.IO.File.Exists("default.txt") Then
            Dim reader As New StreamReader("default.txt")
            txtDir.Text = reader.ReadLine
            reader.Close()

            If System.IO.File.Exists(txtDir.Text) Then
                GetSongsFromPlaylist(txtDir.Text)
            Else
                GetFiles(txtDir.Text)
            End If
        End If
    End Sub

    Private Sub txtDir_Click(sender As Object, e As EventArgs) Handles txtDir.Click
        If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
            txtDir.Text = FolderBrowserDialog1.SelectedPath
            If Not System.IO.File.Exists("default.txt") Then
                Dim file As System.IO.StreamWriter
                file = My.Computer.FileSystem.OpenTextFileWriter("default.txt", True)
                file.WriteLine(txtDir.Text)
                file.Close()
            End If
            GetFiles(txtDir.Text)
        End If
    End Sub

    Private Sub lvMp3_DoubleClick(sender As Object, e As EventArgs) Handles lvMp3.DoubleClick
        If lvMp3.SelectedItems.Count = 1 Then
            index = lvMp3.Items.IndexOf(lvMp3.SelectedItems(0))
            PlayFile(lvMp3.SelectedItems(0).Tag)
        End If
    End Sub

    Public Sub nextSong()
        index += 1
        If index < lvMp3.Items.Count Then

            PlayFile(lvMp3.Items(index).Tag)
        Else
            player.turnOff()
            player.Close()
        End If
    End Sub

    Public Sub prevSong()
        index -= 1
        If index > 0 Then

            PlayFile(lvMp3.Items(index).Tag)

        End If
    End Sub

    Private Sub lvMp3_MouseDown(sender As Object, e As MouseEventArgs) Handles lvMp3.MouseDown
        If lvMp3.SelectedItems.Count = 1 Then
            If e.Button <> MouseButtons.Right Then
                ContextMenuStrip1.BringToFront()
            Else

            End If
        End If
    End Sub

    Private Sub EditTrackToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditTrackToolStripMenuItem.Click
        If lvMp3.SelectedItems.Count = 1 Then
            player.Dispose()
            player.Close()
            frmEditor.GetFile(lvMp3.SelectedItems(0).Tag)
            frmEditor.Show()
        End If
    End Sub

    Private Sub SaveAsPlaylistToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveAsPlaylistToolStripMenuItem.Click
        Dim items As String = ""
        For Each item In lvMp3.CheckedItems
            items += item.tag & vbCrLf
        Next
        Dim dr As DialogResult
        dr = SaveFileDialog1.ShowDialog()
        If dr = DialogResult.OK Then
            System.IO.File.WriteAllText(SaveFileDialog1.FileName, items)
            txtDir.Text = (SaveFileDialog1.FileName)
            GetSongsFromPlaylist(txtDir.Text)
        End If
    End Sub

    Private Sub lvMp3_ColumnClick(sender As Object, e As ColumnClickEventArgs) Handles lvMp3.ColumnClick

        If e.Column <> sortColumn Then
            ' Set the sort column to the new column.
            sortColumn = e.Column
            ' Set the sort order to ascending by default.
            lvMp3.Sorting = SortOrder.Ascending
        Else
            ' Determine what the last sort order was and change it.
            If lvMp3.Sorting = SortOrder.Ascending Then
                lvMp3.Sorting = SortOrder.Descending
            Else
                lvMp3.Sorting = SortOrder.Ascending
            End If
        End If
        ' Call the sort method to manually sort.
        Me.lvMp3.ListViewItemSorter = New ListViewItemComparer(e.Column)
    End Sub

    Private Sub DeleteFromPlaylistToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeleteFromPlaylistToolStripMenuItem.Click
        lvMp3.Items.Remove(lvMp3.SelectedItems(0))
    End Sub

    Private Sub AddToPlaylistToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddToPlaylistToolStripMenuItem.Click
        OpenFileDialog1.Multiselect = True
        Dim dr = OpenFileDialog1.ShowDialog()
        Dim pathnames As String()
        If dr = DialogResult.OK Then
            pathnames = OpenFileDialog1.FileNames
            For Each nFile In pathnames
                AddtoList(nFile)
                lvMp3.Items(lvMp3.Items.Count - 1).Checked = True
            Next
        End If
        OpenFileDialog1.Multiselect = False
    End Sub

    Private Sub SetAsDefault()
        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter("default.txt", False)
        file.WriteLine(txtDir.Text)
        file.Close()
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectAllToolStripMenuItem.Click
        For i = 0 To lvMp3.Items.Count - 1
            lvMp3.Items(i).Checked = True
        Next
    End Sub

    Private Sub SelectNoneToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectNoneToolStripMenuItem.Click
        For i = 0 To lvMp3.Items.Count - 1
            lvMp3.Items(i).Checked = False
        Next
    End Sub

    Private Sub ShowTagToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowTagToolStripMenuItem.Click
        MsgBox(lvMp3.SelectedItems(0).Tag.ToString)
    End Sub

    Private Sub RefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshToolStripMenuItem.Click
        lvMp3.Refresh()
        If System.IO.File.Exists(txtDir.Text) Then
            GetSongsFromPlaylist(txtDir.Text)
        Else
            GetFiles(txtDir.Text)
        End If
    End Sub
End Class

Class ListViewItemComparer
    Implements IComparer

    Private col As Integer

    Public Sub New()
        col = 0
    End Sub

    Public Sub New(ByVal column As Integer)
        col = column
    End Sub

    Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer _
           Implements IComparer.Compare
        Return [String].Compare(CType(x, ListViewItem).SubItems(col).Text, CType(y, ListViewItem).SubItems(col).Text)
    End Function
End Class