﻿Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices
Imports System.Runtime.InteropServices.ComTypes
Imports System.Security.Cryptography
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports AxWMPLib
Imports Id3
Imports WMPLib

Public Class frmPlayer
    Public filepath As String = ""
    Dim playlist As frmPlaylist
    Dim scrollUp As Boolean = False

    Sub turnOff()
        AxWindowsMediaPlayer1.Ctlcontrols.stop()
        PictureBox1.Image = Nothing
        TrackBar.Value = 0
        lblPlaying.Text = "00:00"
    End Sub
    Private Sub GetArt()
        If PictureBox1.Image IsNot Nothing Then
            Timer2.Enabled = False
            Timer2.Stop()
            Exit Sub
        Else
            Dim guid As String = AxWindowsMediaPlayer1.currentMedia.getItemInfo("WM/WMCollectionID")
            PictureBox1.Image = OnMediaGuidAvailable(guid)
        End If
    End Sub
    Private Function OnMediaGuidAvailable(ByVal guid As String) As Image
        If guid.Length < 1 Then
            Return Nothing
        End If
        Dim FileDir As String = Path.GetDirectoryName(AxWindowsMediaPlayer1.currentMedia.sourceURL)
        Dim filename As String = FileDir & "\AlbumArt_" & guid & "_Large.jpg"
        If IO.File.Exists(filename) = False Then
            Return Nothing
        End If
        Dim img As Image = Image.FromFile(filename)
        If Not img Is Nothing Then
            Return img
        End If
        Return Nothing
    End Function
    Public Sub GetFile()
        turnOff()
        Dim title As String = Path.GetFileNameWithoutExtension(filepath)
        Dim artists As String = "Unknown Artist"
        Dim album As String = "Unknown Album"
        Dim lyrics As String = ""
        AxWindowsMediaPlayer1.URL = filepath
        Dim file As Mp3 = New Mp3(filepath, Mp3Permissions.Read)
        Dim tag As Id3Tag = New Id3Tag()
        If file.HasTags Then
            If file.HasTagOfVersion(Id3Version.V1X) Then
                tag = file.GetTag(Id3TagFamily.Version1X)
            Else
                tag = file.GetTag(Id3TagFamily.Version2X)
            End If
            title = tag.Title
            artists = tag.Artists
            album = tag.Album
            'If tag.Lyrics.Count > 0 Then
            'lyrics = tag.Lyrics.FirstOrDefault.Lyrics
            'End If
            If System.IO.File.Exists(filepath + ".txt") Then
                RTBoxLyrics.Text = ""
                Using reader As New StreamReader(filepath + ".txt")
                    Dim line As String
                    Do
                        line = reader.ReadLine
                        If line Is Nothing Then Exit Do
                        RTBoxLyrics.Text += line + vbCrLf
                    Loop
                End Using
                CekLyrics.Checked = True
            End If
        End If
        Label1.Text = title
        Label2.Text = artists
        Label3.Text = album
    End Sub

    Function GetSeconds(Stamp As String) As Long
        Try
            'Try the format "hh:mm:ss", when failed then try "mm:ss"
            Return CDbl(TimeSpan.ParseExact(Stamp, {"hh\:mm\:ss", "mm\:ss"}, System.Globalization.CultureInfo.InvariantCulture).TotalSeconds)
        Catch ex As Exception
            'Invalid Format!
            Return -1
        End Try
    End Function
    Private Sub BtnPlayPause_Click(sender As Object, e As EventArgs) Handles BtnPlayPause.Click
        If AxWindowsMediaPlayer1.URL <> "" Then
            If AxWindowsMediaPlayer1.playState = WMPLib.WMPPlayState.wmppsReady Then
                AxWindowsMediaPlayer1.Ctlcontrols.play()
                Timer1.Enabled = True
                Timer2.Enabled = True
                BtnPlayPause.Image = My.Resources.pause
            ElseIf AxWindowsMediaPlayer1.playState = WMPLib.WMPPlayState.wmppsPlaying Then
                AxWindowsMediaPlayer1.Ctlcontrols.pause()
                Timer1.Enabled = False
                Timer2.Enabled = False
                BtnPlayPause.Image = My.Resources.play
            ElseIf AxWindowsMediaPlayer1.playState = WMPLib.WMPPlayState.wmppsPaused Then
                AxWindowsMediaPlayer1.Ctlcontrols.play()
                Timer1.Enabled = True
                Timer2.Enabled = True
                BtnPlayPause.Image = My.Resources.pause
            End If
        End If
    End Sub
    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick

        Dim duration As String
        lblDuration.Text = AxWindowsMediaPlayer1.currentMedia.durationString
        duration = GetSeconds(lblDuration.Text)
        TrackBar.Maximum = duration
        lblPlaying.Text = AxWindowsMediaPlayer1.Ctlcontrols.currentPositionString
        If TrackBar.Value = TrackBar.Maximum Then
            Timer1.Stop()
            AxWindowsMediaPlayer1.close()
            Timer1.Enabled = False
            frmPlaylist.nextSong()
        Else
            TrackBar.Value = TrackBar.Value + 1
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        GetArt()
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AxWindowsMediaPlayer1.CreateControl()
        AxWindowsMediaPlayer1.Ctlcontrols.play()
        Timer1.Enabled = True
        Timer2.Enabled = True
        BtnPlayPause.Image = My.Resources.pause
        frmPlaylist.WindowState = FormWindowState.Normal
    End Sub

    Private Sub BtnPrev_Click(sender As Object, e As EventArgs) Handles BtnPrev.Click
        frmPlaylist.prevSong()
    End Sub

    Private Sub BtnNext_Click(sender As Object, e As EventArgs) Handles BtnNext.Click
        frmPlaylist.nextSong()
    End Sub

    Private Sub BtnNext_MouseDown(sender As Object, e As MouseEventArgs) Handles BtnNext.MouseDown
        BtnNext.Image = My.Resources.end_filled
    End Sub

    Private Sub BtnPrev_MouseDown(sender As Object, e As MouseEventArgs) Handles BtnPrev.MouseDown
        BtnPrev.Image = My.Resources.start_filled
    End Sub

    Private Sub BtnPrev_MouseUp(sender As Object, e As MouseEventArgs) Handles BtnPrev.MouseUp
        BtnPrev.Image = My.Resources.start
    End Sub

    Private Sub BtnNext_MouseUp(sender As Object, e As MouseEventArgs) Handles BtnNext.MouseUp
        BtnNext.Image = My.Resources._end
    End Sub

    Private Sub VolumeBar_Scroll(sender As Object, e As EventArgs) Handles VolumeBar.Scroll
        AxWindowsMediaPlayer1.settings.volume = VolumeBar.Value
    End Sub

    Private Sub TrackBar_Scroll(sender As Object, e As EventArgs) Handles TrackBar.Scroll
        AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = TrackBar.Value
    End Sub

    Private Sub BtnBack_Click(sender As Object, e As EventArgs) Handles BtnBack.Click
        frmPlaylist.WindowState = FormWindowState.Normal
        frmPlaylist.BringToFront()
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub frmPlayer_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        turnOff()
        AxWindowsMediaPlayer1.currentPlaylist.clear()
        AxWindowsMediaPlayer1.close()
        AxWindowsMediaPlayer1.URL = ""
        AxWindowsMediaPlayer1.Dispose()
        Timer1.Stop()
        Timer2.Stop()
        frmPlaylist.WindowState = FormWindowState.Normal
    End Sub

    Private Sub CekLyrics_CheckedChanged(sender As Object, e As EventArgs) Handles CekLyrics.CheckedChanged
        RTBoxLyrics.Visible = CekLyrics.Checked
        If CekLyrics.Checked = True Then
            CekLyrics.Location = New Point(RTBoxLyrics.Location.X - 90, 12)
        Else
            CekLyrics.Location = New Point(Me.Width - 117, 12)
        End If
    End Sub
End Class
