﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPlayer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPlayer))
        Me.VolumeBar = New System.Windows.Forms.TrackBar()
        Me.TrackBar = New System.Windows.Forms.TrackBar()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lblPlaying = New System.Windows.Forms.Label()
        Me.lblDuration = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.BtnPrev = New System.Windows.Forms.PictureBox()
        Me.BtnNext = New System.Windows.Forms.PictureBox()
        Me.BtnPlayPause = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.BtnBack = New System.Windows.Forms.Button()
        Me.AxWindowsMediaPlayer1 = New AxWMPLib.AxWindowsMediaPlayer()
        Me.RTBoxLyrics = New System.Windows.Forms.RichTextBox()
        Me.CekLyrics = New System.Windows.Forms.CheckBox()
        CType(Me.VolumeBar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BtnPrev, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BtnNext, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BtnPlayPause, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'VolumeBar
        '
        Me.VolumeBar.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.VolumeBar.Location = New System.Drawing.Point(124, 419)
        Me.VolumeBar.Maximum = 100
        Me.VolumeBar.Name = "VolumeBar"
        Me.VolumeBar.Size = New System.Drawing.Size(104, 45)
        Me.VolumeBar.TabIndex = 4
        Me.VolumeBar.Value = 100
        '
        'TrackBar
        '
        Me.TrackBar.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.TrackBar.Location = New System.Drawing.Point(197, 368)
        Me.TrackBar.Name = "TrackBar"
        Me.TrackBar.Size = New System.Drawing.Size(375, 45)
        Me.TrackBar.TabIndex = 5
        Me.TrackBar.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'lblPlaying
        '
        Me.lblPlaying.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.lblPlaying.AutoSize = True
        Me.lblPlaying.Location = New System.Drawing.Point(194, 352)
        Me.lblPlaying.Name = "lblPlaying"
        Me.lblPlaying.Size = New System.Drawing.Size(34, 13)
        Me.lblPlaying.TabIndex = 7
        Me.lblPlaying.Text = "00:00"
        '
        'lblDuration
        '
        Me.lblDuration.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.lblDuration.AutoSize = True
        Me.lblDuration.Location = New System.Drawing.Point(548, 352)
        Me.lblDuration.Name = "lblDuration"
        Me.lblDuration.Size = New System.Drawing.Size(34, 13)
        Me.lblDuration.TabIndex = 8
        Me.lblDuration.Text = "00:00"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(201, 257)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(371, 26)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Label1"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(197, 294)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(375, 20)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Label2"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(197, 325)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(375, 20)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Label3"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BtnPrev
        '
        Me.BtnPrev.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.BtnPrev.Image = Global.YAMP.My.Resources.Resources.start
        Me.BtnPrev.Location = New System.Drawing.Point(267, 409)
        Me.BtnPrev.Name = "BtnPrev"
        Me.BtnPrev.Size = New System.Drawing.Size(75, 75)
        Me.BtnPrev.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.BtnPrev.TabIndex = 3
        Me.BtnPrev.TabStop = False
        '
        'BtnNext
        '
        Me.BtnNext.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.BtnNext.Image = Global.YAMP.My.Resources.Resources._end
        Me.BtnNext.Location = New System.Drawing.Point(429, 409)
        Me.BtnNext.Name = "BtnNext"
        Me.BtnNext.Size = New System.Drawing.Size(75, 75)
        Me.BtnNext.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.BtnNext.TabIndex = 2
        Me.BtnNext.TabStop = False
        '
        'BtnPlayPause
        '
        Me.BtnPlayPause.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.BtnPlayPause.Image = Global.YAMP.My.Resources.Resources.pause
        Me.BtnPlayPause.Location = New System.Drawing.Point(348, 409)
        Me.BtnPlayPause.Name = "BtnPlayPause"
        Me.BtnPlayPause.Size = New System.Drawing.Size(75, 75)
        Me.BtnPlayPause.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.BtnPlayPause.TabIndex = 1
        Me.BtnPlayPause.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PictureBox1.InitialImage = Nothing
        Me.PictureBox1.Location = New System.Drawing.Point(281, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(214, 214)
        Me.PictureBox1.TabIndex = 12
        Me.PictureBox1.TabStop = False
        '
        'Timer2
        '
        Me.Timer2.Interval = 1000
        '
        'BtnBack
        '
        Me.BtnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnBack.Location = New System.Drawing.Point(12, 12)
        Me.BtnBack.Name = "BtnBack"
        Me.BtnBack.Size = New System.Drawing.Size(49, 47)
        Me.BtnBack.TabIndex = 13
        Me.BtnBack.Text = "←"
        Me.BtnBack.UseVisualStyleBackColor = True
        '
        'AxWindowsMediaPlayer1
        '
        Me.AxWindowsMediaPlayer1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.AxWindowsMediaPlayer1.Enabled = True
        Me.AxWindowsMediaPlayer1.Location = New System.Drawing.Point(12, 155)
        Me.AxWindowsMediaPlayer1.Name = "AxWindowsMediaPlayer1"
        Me.AxWindowsMediaPlayer1.OcxState = CType(resources.GetObject("AxWindowsMediaPlayer1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxWindowsMediaPlayer1.Size = New System.Drawing.Size(75, 23)
        Me.AxWindowsMediaPlayer1.TabIndex = 6
        Me.AxWindowsMediaPlayer1.Visible = False
        '
        'RTBoxLyrics
        '
        Me.RTBoxLyrics.Dock = System.Windows.Forms.DockStyle.Right
        Me.RTBoxLyrics.Location = New System.Drawing.Point(609, 0)
        Me.RTBoxLyrics.Name = "RTBoxLyrics"
        Me.RTBoxLyrics.Size = New System.Drawing.Size(191, 496)
        Me.RTBoxLyrics.TabIndex = 14
        Me.RTBoxLyrics.Text = "Not found in metadata"
        Me.RTBoxLyrics.Visible = False
        '
        'CekLyrics
        '
        Me.CekLyrics.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CekLyrics.AutoSize = True
        Me.CekLyrics.Location = New System.Drawing.Point(699, 12)
        Me.CekLyrics.Name = "CekLyrics"
        Me.CekLyrics.Size = New System.Drawing.Size(89, 17)
        Me.CekLyrics.TabIndex = 15
        Me.CekLyrics.Text = "Toggle Lyrics"
        Me.CekLyrics.UseVisualStyleBackColor = True
        '
        'frmPlayer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 496)
        Me.Controls.Add(Me.CekLyrics)
        Me.Controls.Add(Me.RTBoxLyrics)
        Me.Controls.Add(Me.BtnBack)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblDuration)
        Me.Controls.Add(Me.lblPlaying)
        Me.Controls.Add(Me.AxWindowsMediaPlayer1)
        Me.Controls.Add(Me.VolumeBar)
        Me.Controls.Add(Me.BtnPrev)
        Me.Controls.Add(Me.BtnNext)
        Me.Controls.Add(Me.BtnPlayPause)
        Me.Controls.Add(Me.TrackBar)
        Me.Name = "frmPlayer"
        Me.Text = "Player"
        CType(Me.VolumeBar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BtnPrev, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BtnNext, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BtnPlayPause, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BtnPlayPause As PictureBox
    Friend WithEvents BtnNext As PictureBox
    Friend WithEvents BtnPrev As PictureBox
    Friend WithEvents VolumeBar As TrackBar
    Friend WithEvents TrackBar As TrackBar
    Friend WithEvents AxWindowsMediaPlayer1 As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents Timer1 As Timer
    Friend WithEvents lblPlaying As Label
    Friend WithEvents lblDuration As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents BtnBack As Button
    Friend WithEvents RTBoxLyrics As RichTextBox
    Friend WithEvents CekLyrics As CheckBox
End Class
